#include <catch.hpp>

#include "../ObjectPool.h"
#include "../go/GoAlloc.h"

TEST_CASE("Test object creation", "[ObjectPool]") {
    struct A {
        int i, j;
        float f;

        A(int _i, int _j, float _f) : i(_i), j(_j), f(_f) {}
    };

    ObjectPool<A> pool(100);

    A *a1 = nullptr, *a2 = nullptr, *a3 = nullptr;

    REQUIRE_NOTHROW(a1 = pool.New(1, 2, 0.5f));
    REQUIRE(a1 != nullptr);
    REQUIRE(a1->i == 1);
    REQUIRE(a1->j == 2);
    REQUIRE_NOTHROW(a2 = pool.New(1, 1, 0.1f));
    REQUIRE(a2 != nullptr);
    REQUIRE(a2->i == 1);
    REQUIRE(a2->j == 1);

    REQUIRE_NOTHROW(pool.Delete(a1));

    REQUIRE_NOTHROW(a3 = pool.New(2, 3, 0.2f));
    REQUIRE(a3 != nullptr);
    REQUIRE(a3->i == 2);
    REQUIRE(a3->j == 3);

    REQUIRE(a1 == a3);
}

TEST_CASE("Test new node allocation", "[ObjectPool]") {
    struct A {
        int i, j;
        double d1, d2;

        A(int _i) : i(_i), j(_i), d1(_i), d2(_i) {}
    };

    ObjectPool<A> pool(2);

    A *a1, *a2, *a3;

    a1 = pool.New(1);
    a2 = pool.New(2);
    a3 = pool.New(3);

    pool.Delete(a1);
    pool.Delete(a2);
    pool.Delete(a3);
}


TEST_CASE("ObjectPool test", "[ObjectPool]") {
    struct A {
        int i, j;
        double d1, d2;

        A(int _i) : i(_i), j(_i), d1(_i), d2(_i) {}
    };

    A *a1 = GoAlloc<A>::New(1);
    GoAlloc<A>::Delete(a1);

    GoAlloc<A>::Ref a2 = GoAlloc<A>::NewU(2);

    GoRef<A> a3 = GoAlloc<A>::NewU(3);
}
